from pages.amazon_page import AmazonPage


def test_amazon_search_shows_product_results(driver):
    page = AmazonPage(driver)
    page.open_homepage()
    page.search("wireless mouse")

    titles = page.result_titles()

    assert titles, "Expected at least one visible product title."
    assert any("mouse" in title.lower() for title in titles), (
        "Expected at least one search result title related to 'mouse'."
    )
