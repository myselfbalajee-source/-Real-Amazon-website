from pages.amazon_page import AmazonPage


def test_open_product_and_verify_title(driver):
    page = AmazonPage(driver)
    page.open_homepage()
    page.search("notebook")

    page.open_first_product()
    title = page.product_title()

    assert title, "Expected a non-empty product title on the detail page."
    assert len(title) >= 3, "Product title appears too short to be valid."
