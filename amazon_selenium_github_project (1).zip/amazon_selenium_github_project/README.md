# Amazon Website Testing with Selenium (Python)

A beginner-friendly Selenium + pytest project that tests basic public shopping flows on **Amazon India**:
- Open Amazon.in
- Search for a product
- Check that the search results page loads and contains product listings
- Open a result and verify that a product detail page is displayed

This project does **not** sign in, add items to a cart, place orders, bypass CAPTCHA, or attempt to evade anti-bot controls.

## Requirements
- Python 3.10 or newer
- Google Chrome installed
- Internet connection

## 1. Download and extract
Extract this project folder to a convenient location, for example:
`C:\Users\<your-user>\Documents\amazon-selenium-project`

## 2. Open in VS Code
In VS Code, choose **File → Open Folder** and select the extracted folder.

## 3. Create a virtual environment
Open **Terminal → New Terminal** in VS Code (PowerShell), then run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, run this for the current terminal only, then activate again:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 4. Run the tests
Run from the project root in the VS Code terminal:

```powershell
pytest -v
```

To run only the search test:
```powershell
pytest -v tests/test_amazon_search.py
```

To run only the product page test:
```powershell
pytest -v tests/test_product_details.py
```

Amazon may show a CAPTCHA, consent page, regional redirect, or change its HTML. If that happens, stop the test and retry later or update the locators. Do not try to bypass CAPTCHA or access controls.

## 5. View the report
The tests print results in the terminal. To create a JUnit XML report:
```powershell
pytest -v --junitxml=reports/test-results.xml
```
The `reports` folder is already included in the repository.

## 6. Upload the project to GitHub

### Create a repository
1. Sign in at https://github.com/
2. Click **+ → New repository**.
3. Repository name: `amazon-selenium-testing`
4. Choose **Public** (if your course allows it) or **Private**.
5. Click **Create repository**. You can skip adding a README because this project already has one.

### Push using VS Code terminal
Replace `YOUR-GITHUB-USERNAME` with your GitHub username:
```powershell
git init
git add .
git commit -m "Add Amazon Selenium testing project"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/amazon-selenium-testing.git
git push -u origin main
```

If Git says your name/email are not configured, set them (use the email associated with your GitHub account):
```powershell
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```
Then repeat the commit and push commands. If Git is not installed, install Git from https://git-scm.com/downloads and reopen VS Code.

## Project structure

```text
amazon-selenium-testing/
├── .github/
│   └── workflows/
│       └── tests.yml
├── pages/
│   ├── __init__.py
│   └── amazon_page.py
├── tests/
│   ├── __init__.py
│   ├── test_amazon_search.py
│   └── test_product_details.py
├── reports/
│   └── .gitkeep
├── .gitignore
├── conftest.py
├── pytest.ini
├── requirements.txt
└── README.md
```

## What the tests validate
1. **Search test:** search input is available, a query can be submitted, the URL/page indicates search results, and visible product titles are present.
2. **Product detail test:** opens the first usable result and verifies the product page has a non-empty title.

## Notes for your submission
- Run the tests locally and include a screenshot of the pytest results in your project submission if required.
- GitHub Actions is configured as an optional CI example. Real retail sites may block or challenge automated traffic, so CI results may vary.
- This is an educational demonstration, not a guarantee that Amazon's UI or selectors remain unchanged.
