from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class AmazonPage:
    BASE_URL = "https://www.amazon.in/"

    SEARCH_BOX = (By.ID, "twotabsearchtextbox")
    SEARCH_BUTTON = (By.ID, "nav-search-submit-button")
    RESULT_TITLES = (
        By.CSS_SELECTOR,
        "div.s-main-slot h2 a span"
    )
    PRODUCT_LINKS = (
        By.CSS_SELECTOR,
        "div.s-main-slot h2 a.a-link-normal"
    )
    PRODUCT_TITLE = (By.ID, "productTitle")

    def __init__(self, driver, timeout=20):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open_homepage(self):
        self.driver.get(self.BASE_URL)

    def search(self, phrase):
        box = self.wait.until(EC.visibility_of_element_located(self.SEARCH_BOX))
        box.clear()
        box.send_keys(phrase)
        box.send_keys(Keys.ENTER)
        self.wait.until(
            lambda d: "s?k=" in d.current_url or
            len(d.find_elements(*self.RESULT_TITLES)) > 0
        )

    def result_titles(self):
        self.wait.until(
            lambda d: len(d.find_elements(*self.RESULT_TITLES)) > 0
        )
        return [
            element.text.strip()
            for element in self.driver.find_elements(*self.RESULT_TITLES)
            if element.text.strip()
        ]

    def open_first_product(self):
        links = self.wait.until(
            EC.presence_of_all_elements_located(self.PRODUCT_LINKS)
        )
        for link in links:
            href = link.get_attribute("href")
            if href and "/dp/" in href:
                self.driver.get(href)
                return
        raise AssertionError("No usable product detail link was found in the results.")

    def product_title(self):
        title = self.wait.until(
            EC.visibility_of_element_located(self.PRODUCT_TITLE)
        )
        return title.text.strip()
