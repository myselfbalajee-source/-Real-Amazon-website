import os
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def driver():
    """Create a Chrome browser session. Selenium Manager resolves the driver."""
    options = Options()
    if os.getenv("HEADLESS", "0") == "1":
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1365,900")
    options.add_argument("--disable-notifications")
    options.add_argument("--lang=en-IN")
    browser = webdriver.Chrome(options=options)
    browser.set_page_load_timeout(40)
    yield browser
    browser.quit()
